from django.test import TestCase

class WechatApiTest(TestCase):

    def test_api(self):
        pass
